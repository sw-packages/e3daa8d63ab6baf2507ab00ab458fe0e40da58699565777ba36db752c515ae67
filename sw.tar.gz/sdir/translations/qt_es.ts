<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
    <dependencies>
        <dependency catalog="qtbase_es"/>
        <dependency catalog="qtmultimedia_es"/>
        <dependency catalog="qtscript_es"/>
        <dependency catalog="qtxmlpatterns_es"/>
    </dependencies>
</TS>
