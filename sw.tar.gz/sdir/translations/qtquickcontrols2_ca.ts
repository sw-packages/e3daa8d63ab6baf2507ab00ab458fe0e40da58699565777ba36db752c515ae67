<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ca" sourcelanguage="en">
<context>
    <name>QQuickPlatformDialog</name>
    <message>
        <source>Dialog is an abstract base class</source>
        <translation>El diàleg és una classe de base abstracta</translation>
    </message>
    <message>
        <source>Cannot create an instance of StandardButton</source>
        <translation>No s&apos;ha pogut crear una instància de «StandardButton»</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2ImagineStylePlugin</name>
    <message>
        <source>Imagine is an attached property</source>
        <translation>«Imagine» és una propietat adjunta</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2MaterialStylePlugin</name>
    <message>
        <source>Material is an attached property</source>
        <translation>«Material» és una propietat adjunta</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2UniversalStylePlugin</name>
    <message>
        <source>Universal is an attached property</source>
        <translation>«Universal» és una propietat adjunta</translation>
    </message>
</context>
</TS>
